#!/bin/bash

# 1. Загрузка исходного CSV в HDFS
hdfs dfs -mkdir -p /user/cloudera/input
hdfs dfs -put -f ~/task/metro.csv /user/cloudera/input/

# 2. Запуск MapReduce через Hadoop Streaming
hadoop jar /usr/lib/hadoop-mapreduce/hadoop-streaming.jar \
  -input /user/cloudera/input/metro.csv \
  -output /user/cloudera/output_metro \
  -mapper mapper.py \
  -reducer reducer.py \
  -file mapper.py \
  -file reducer.py

# 3. Выгрузка результата из HDFS
hdfs dfs -get -f /user/cloudera/output_metro/part-00000 ~/task/result.txt

# 4. Формирование топ10
sort -k2 -nr ~/task/result.txt | head -n 10 > ~/task/top10.tsv
