#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys

for line in sys.stdin:
	line = line.strip()
	if not line:
		continue

	parts = line.split(';')
	
	station = parts[0].strip().strip('"').strip()
	entries_raw = parts[4].strip().strip('"').strip()
	exits_raw = parts[5].strip().strip('"').strip()

	if station in ("Metro station name", "Станция метрополитена"):
        	continue
 	if entries_raw in ("Incoming passengers", "Входы пассажиров"):
        	continue
    	if not station:
        	continue

    	try:
        	entries = int(entries_raw)
        	exits = int(exits_raw)
    	except ValueError:
        	continue

    	passenger_flow = entries + exits

    	print "%s\t%d" % (station, passenger_flow)
