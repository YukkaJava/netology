#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys

current_station = None
current_count = 0

for line in sys.stdin:
	line = line.strip()
	try:
		station, count = line.split('\t', 1)
		count = int(count)
	except ValueError:
		continue

	if current_station == station:
		current_count += count
	else:
        	if current_station:
			 print "%s\t%d" % (current_station, current_count)
		current_station = station
		current_count = count

if current_station:
	print "%s\t%d" % (current_station, current_count)
